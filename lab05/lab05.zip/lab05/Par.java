package mc322.lab05;

public class Par {
    public int x;
    public int y;
    
    Par(int x, int y)
    {
        this.x=x;
        this.y=y;
    }
}

