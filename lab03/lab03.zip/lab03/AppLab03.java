package mc322.lab03;

public class AppLab03 {

	public static void main(String[] args) {
		Animacao anim1 = new Animacao("042002MCMMVM");
	}

}
